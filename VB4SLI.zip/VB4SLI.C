#include "VB4SLI.H"
#include "messages.h"

#define MAX_MSG_LENGTH 1024
#define MSG_ID_MASK 0x0000FFFF
#define MAX_INSERT_STRS 8

char *aInsertStrs[MAX_INSERT_STRS];   /* array of pointers to insert
                                         strings */

/**PROC+**********************************************************************/
/* Name:      LibMain                                                        */
/*                                                                           */
/* Purpose:   Initialize the DLL                                             */
/*                                                                           */
/* Returns:   TRUE                                                           */
/*                                                                           */
/* Params:    HANDLE, DWORD, LPVOID                                          */
/*                                                                           */
/* Operation: return TRUE                                                    */
/*                                                                           */
/**PROC-**********************************************************************/

BOOL WINAPI DllMain( HANDLE hDll, DWORD dwReason, LPVOID lpReserved )
{
  char szMsgPath[MAX_PATH];
  if (dwReason==DLL_PROCESS_ATTACH)
    {
     // GetCurrentDirectory(sizeof(szMsgPath), szMsgPath);
  	 GetSystemDirectory(
                        szMsgPath, // address of buffer for system directory 
                        MAX_PATH 	// size of directory buffer 
                       );	
     strcat(szMsgPath, "\\vb4sli.dll");
     addSourceToRegistry(szMsgPath);
    }
  return (TRUE);

}/* LibMain                                                                  */



BSTR WINAPI VB4SLICONNECT(BSTR *LUName,
                          BSTR *AppId,
                          long ConvertIt,
                          long TimeOut,
                          long *Ret1,
                          long *Ret2,
                          long *Ret3,
                          long DebugIt)

{
 UCHAR logon_data[25] = {0x01,0x06,0x81,0x00,0x40,0x40,0x40,0x40,0x40,0x40,
                         0x40,0x40,0xf3,0x08,0xc3,0xc9,0xc3,0xe2,0xc1,0x40,
                         0x40,0x40,0x00,0x00,0x00};
 DWORD RetCode=0;
 BSTR retData;
 if (Sid!=0)
   {
    *Ret1= -1;
    *Ret2= -1;
    *Ret3=  0;
    wsprintf(msgBuff,"%s",TEXT("Already connected!"));
    retData=SysAllocStringByteLen(msgBuff,lstrlen(msgBuff));
    if (DebugIt!=0)                       // use it as debug flag
      {
       aInsertStrs[0] = crlf;
       aInsertStrs[1] = cicsBuff;
       aInsertStrs[2] = luBuff;
       reportAnEvent( EVENTLOG_ERROR_TYPE,
                      MSG_SLI_ALREADY_CONNECTED, /* the message to log */
                      3,              /* number of insert strings */
                      aInsertStrs,0,NULL);    /* the array of insert strings */
       if (DebugIt==2)
          MessageBox(NULL,msgBuff,TEXT("VB4SliConnect Return Codes"),MB_OK);
       /* Set up our array of insert strings for error message */
      }
    return retData;
   }
 LenData=0;
 LastStatus=0;
 Sid=0;
 rpq_neaded = FALSE;
 send_state = BETB;
 memset(SendBuff, 0, DATASIZE+1);
 memset(RecvBuff, 0, DATASIZE+1);

 wsprintf(cics_name,"%s",*AppId);
 wsprintf(lu_name,"%s",*LUName);
 wsprintf(cicsBuff,"%s",*AppId);

 strcat(cicsBuff,crlf);
 wsprintf(luBuff,"%s",*LUName);
 strcat(luBuff,crlf);

 if (strlen(cics_name)==8)
   {
     if (ConvertIt!=0)
       {
        convert_to_ebc.opcode       = SV_CONVERT;
        convert_to_ebc.direction    = SV_ASCII_TO_EBCDIC;
        convert_to_ebc.char_set     = SV_G;
        convert_to_ebc.source       = cics_name;
        convert_to_ebc.target       = cics_name;
        convert_to_ebc.len          = 8;
        ACSSVC_C((LONG)((UCHAR FAR *)&convert_to_ebc));
       }
     memcpy(logon_data+CICSOFFSET,cics_name,8); //Must have CICS to connect
                                                //padded with spaces
    }

  init_event  = CreateEvent (NULL, TRUE, FALSE, NULL);
  write_event = CreateEvent (NULL, TRUE, FALSE, NULL);
  read_event  = CreateEvent (NULL, TRUE, FALSE, NULL);
  rpq_event   = CreateEvent (NULL, TRUE, FALSE, NULL);

  memset(&other_verb, 0, sizeof(other_verb));
  other_verb.common.lua_verb             = LUA_VERB_SLI;
  other_verb.common.lua_opcode           = LUA_OPCODE_SLI_OPEN;
  other_verb.common.lua_verb_length    = sizeof(struct LUA_COMMON)+
                            sizeof(other_verb.specific.open.lua_init_type) +
                            sizeof(other_verb.specific.open.lua_resv65) +
                            sizeof(other_verb.specific.open.lua_wait) +
                            sizeof(other_verb.specific.open.lua_ending_delim);
  memcpy(other_verb.common.lua_luname, lu_name, 8);
  other_verb.specific.open.lua_wait    = 2;
  other_verb.common.lua_post_handle    = OPENPOST;
  other_verb.specific.open.lua_init_type = LUA_INIT_TYPE_SEC_IS;
  other_verb.common.lua_data_length    = 25;
  other_verb.common.lua_data_ptr       = logon_data;
  other_verb.specific.open.lua_open_extension[0].lua_routine_type =
                                                         LUA_ROUTINE_TYPE_END;
  SLI((LUA_VERB_RECORD *) &other_verb);

  if (other_verb.common.lua_flag2.async)
     RetCode=wait_verb_complete (&other_verb,(int) TimeOut);

  *Ret1=(long) other_verb.common.lua_prim_rc;
  *Ret2=(long) other_verb.common.lua_sec_rc;
  *Ret3=send_state;

  if (RetCode==TIMEOUT_ERROR)
    {
     *Ret3=0;
     wsprintf(msgBuff,"%s",TEXT("Timeout on connect"));
     retData=SysAllocStringByteLen(msgBuff,lstrlen(msgBuff));
     if (DebugIt!=0)                       // use it as debug flag
       {
        aInsertStrs[0] = "CONNECT";
        aInsertStrs[1] = crlf;
        aInsertStrs[2] = cicsBuff;
        aInsertStrs[3] = luBuff;
        reportAnEvent( EVENTLOG_ERROR_TYPE,
                       MSG_SLI_TIMEOUT, /* the message to log */
                       4,              /* number of insert strings */
                       aInsertStrs,0,NULL);    /* the array of insert strings */
        if (DebugIt==2)
           MessageBox(NULL,msgBuff,TEXT("SLI CONNECT Return Codes"),MB_OK);
       }
    }
  else
      {
      if (*Ret1==LUA_OK)
        {
         Sid=other_verb.common.lua_sid;
         retData=SysAllocStringByteLen(NULL,0);
         if (DebugIt!=0)
           {
            GetLuaReturnCode( &other_verb.common,255,msgBuff);
            aInsertStrs[0] = "CONNECT";
            aInsertStrs[1] = crlf;
            aInsertStrs[2] = cicsBuff;
            aInsertStrs[3] = luBuff;
            aInsertStrs[4] = msgBuff;
            reportAnEvent( EVENTLOG_INFORMATION_TYPE,
                           MSG_SLI_SUCCESS, /* the message to log */
                           5,               /* number of insert strings */
                           aInsertStrs,0,NULL);    /* the array of insert strings */
           }
        }
      else
          {
           Sid=0;
           GetLuaReturnCode( &other_verb.common,255,msgBuff);
           retData=SysAllocStringByteLen(msgBuff,lstrlen(msgBuff));
           if (DebugIt!=0)                       // use it as debug flag
             {
              aInsertStrs[0] = "CONNECT";
              aInsertStrs[1] = crlf;
              aInsertStrs[2] = cicsBuff;
              aInsertStrs[3] = luBuff;
              aInsertStrs[4] = msgBuff;
              reportAnEvent( EVENTLOG_ERROR_TYPE,
                             MSG_SLI_ERROR, /* the message to log */
                             5,              /* number of insert strings */
                             aInsertStrs,0,NULL);    /* the array of insert strings */
              if (DebugIt==2)
                 MessageBox(NULL,msgBuff,TEXT("SLI CONNECT Return Codes"),MB_OK);
             }
           }
      }
  return retData;
}

BSTR WINAPI VB4SLIDISCONNECT(long TimeOut,
                             long *Ret1,
                             long *Ret2,
                             long *Ret3,
                             long DebugIt)
{
 DWORD RetCode=0;
 BSTR retData;
 if (Sid==0)
   {
    *Ret1= -1;
    *Ret2= -1;
    *Ret3=  0;
    wsprintf(msgBuff,"%s",TEXT("Not connected!"));
    retData=SysAllocStringByteLen(msgBuff,lstrlen(msgBuff));
    if (DebugIt!=0)                       // use it as debug flag
      {
       aInsertStrs[0] = "DISCONNECT";
       reportAnEvent( EVENTLOG_WARNING_TYPE,
                      MSG_SLI_NOT_CONNECTED, /* the message to log */
                      1,              /* number of insert strings */
                      aInsertStrs,0,NULL);    /* the array of insert strings */
       if (DebugIt==2)
          MessageBox(NULL,msgBuff,TEXT("VB4SliDisconnect Return Codes"),MB_OK);
      }
    return retData;
   }

  term_event  = CreateEvent (NULL, TRUE, FALSE, NULL);

  memset(&other_verb, 0, sizeof(other_verb));
  other_verb.common.lua_verb             = LUA_VERB_SLI;
  other_verb.common.lua_opcode           = LUA_OPCODE_SLI_CLOSE;
  other_verb.common.lua_verb_length    = sizeof(struct LUA_COMMON);
  other_verb.common.lua_sid            = Sid;
  other_verb.specific.open.lua_wait    = 2;
  other_verb.common.lua_post_handle    = CLOSEPOST;
  
  SLI((LUA_VERB_RECORD *) &other_verb);

  if (other_verb.common.lua_flag2.async)
     RetCode=wait_verb_complete (&other_verb,(int) TimeOut);

  *Ret1=(long) other_verb.common.lua_prim_rc;
  *Ret2=(long) other_verb.common.lua_sec_rc;
  *Ret3=send_state;

  if (RetCode==TIMEOUT_ERROR)
    {
     *Ret3=0;
     wsprintf(msgBuff,"%s",TEXT("Timeout on disconnect"));
     retData=SysAllocStringByteLen(msgBuff,lstrlen(msgBuff));
     if (DebugIt!=0)                       // use it as debug flag
       {
        aInsertStrs[0] = "DISCONNECT";
        aInsertStrs[1] = crlf;
        aInsertStrs[2] = cicsBuff;
        aInsertStrs[3] = luBuff;
        reportAnEvent( EVENTLOG_ERROR_TYPE,
                       MSG_SLI_TIMEOUT, /* the message to log */
                       4,              /* number of insert strings */
                       aInsertStrs,0,NULL);    /* the array of insert strings */
        if (DebugIt==2)
           MessageBox(NULL,msgBuff,TEXT("SLI DISCONNECT Return Codes"),MB_OK);
       }
     return retData;
    }

  if (*Ret1==LUA_OK)
    {
//     LenData=0;
//     LastStatus=0;
//     Sid=0;
//     memset(lu_name,0,8);
//     retData=SysAllocStringByteLen(NULL,0);
     if (DebugIt!=0)
       {
        GetLuaReturnCode( &other_verb.common,255,msgBuff);
        aInsertStrs[0] = "DISCONNECT";
        aInsertStrs[1] = crlf;
        aInsertStrs[2] = cicsBuff;
        aInsertStrs[3] = luBuff;
        aInsertStrs[4] = msgBuff;
        reportAnEvent( EVENTLOG_INFORMATION_TYPE,
                       MSG_SLI_SUCCESS, /* the message to log */
                       5,               /* number of insert strings */
                       aInsertStrs,0,NULL);    /* the array of insert strings */
       }
    }
  else
      {
       GetLuaReturnCode( &other_verb.common,255,msgBuff);
       retData=SysAllocStringByteLen(msgBuff,lstrlen(msgBuff));
       if (DebugIt!=0)                       // use it as debug flag
         {
          aInsertStrs[0] = "DISCONNECT";
          aInsertStrs[1] = crlf;
          aInsertStrs[2] = cicsBuff;
          aInsertStrs[3] = luBuff;
          aInsertStrs[4] = msgBuff;
          reportAnEvent( EVENTLOG_ERROR_TYPE,
                         MSG_SLI_ERROR, /* the message to log */
                         5,              /* number of insert strings */
                         aInsertStrs,0,NULL);    /* the array of insert strings */
          if (DebugIt==2)
             MessageBox(NULL,msgBuff,TEXT("SLI DISCONNECT Return Codes"),MB_OK);
         }
       }
 LenData=0;
 LastStatus=0;
 Sid=0;
 memset(lu_name,0,8);
 retData=SysAllocStringByteLen(NULL,0);
 return retData;
}

BSTR WINAPI VB4SLISEND(BSTR *Data,
                       long ConvertIt,
                       long TimeOut,
                       long *Len,
                       long *MsgType,
                       long *Ret1,
                       long *Ret2,
                       long *Ret3,
                       long DebugIt )
{
 DWORD RetCode=0;
 BSTR retData;
 unsigned char dataBuff[DATASIZE+1];
 unsigned char *ptr;
 if (*Len>DATASIZE)
    *Len=DATASIZE;
 if (Sid==0)
   {
    *Ret1= -1;
    *Ret2= -1;
    *Ret3=  0;
    wsprintf(msgBuff,"%s",TEXT("Not connected!"));
    retData=SysAllocStringByteLen(msgBuff,lstrlen(msgBuff));
    if (DebugIt!=0)                       // use it as debug flag
      {
       aInsertStrs[0] = "SEND";
       reportAnEvent( EVENTLOG_ERROR_TYPE,
                      MSG_SLI_NOT_CONNECTED, /* the message to log */
                      1,              /* number of insert strings */
                      aInsertStrs,0,NULL);    /* the array of insert strings */
       if (DebugIt==2)
          MessageBox(NULL,msgBuff,TEXT("VB4SliSend Return Codes"),MB_OK);
      }
    return retData;
   }

  if (*Ret3>0)
     send_state=*Ret3;

  if (rpq_neaded)
     rpq_neaded=issue_rpq((int) TimeOut,DebugIt,send_state);
  ptr=BSTR2String(*Data,0);
  memcpy(SendBuff,ptr,*Len+1);
  free(ptr);
  /***************************************************************************/
  /* Set up the vcb                                                          */
  /***************************************************************************/
  if (ConvertIt!=0)
    {
     convert_to_ebc.opcode       = SV_CONVERT;
     convert_to_ebc.direction    = SV_ASCII_TO_EBCDIC;
     convert_to_ebc.char_set     = SV_G;
     convert_to_ebc.source       = SendBuff;
     convert_to_ebc.target       = SendBuff;
     convert_to_ebc.len          = (unsigned short) (*Len);
     ACSSVC_C((LONG)((UCHAR FAR *)&convert_to_ebc));
    }
  memset(&other_verb, 0, sizeof(other_verb));
  other_verb.common.lua_sid              = Sid;
  other_verb.common.lua_verb             = LUA_VERB_SLI;
  other_verb.common.lua_verb_length      = sizeof(struct LUA_COMMON) +
                         sizeof(other_verb.specific.lua_sequence_number);
  other_verb.common.lua_opcode           = LUA_OPCODE_SLI_SEND;
  other_verb.common.lua_message_type     = LUA_MESSAGE_TYPE_LU_DATA;
  other_verb.common.lua_post_handle      = SENDPOST;
  other_verb.common.lua_rh.dr1i          = 1;

  other_verb.common.lua_data_length      = (USHORT) *Len;
  other_verb.common.lua_data_ptr         = SendBuff;

  /***************************************************************************/
  /* On the LU session we must add the <enter> key prefix.  All inbound      */
  /* requests flow RQE with the BBI and CDI flags set depending on the       */
  /* current session state.                                                  */
  /***************************************************************************/
  other_verb.common.lua_rh.ri          = 1;
  if (send_state == BETB)
  {
    /*************************************************************************/
    /* Between bracket, so open bracket and give direction.  Note that we    */
    /* can do this since we will always be contention winner.                */
    /*************************************************************************/
    other_verb.common.lua_rh.bbi         = 1;
    other_verb.common.lua_rh.cdi         = 1;
    send_state = RECV;
  }
  else if (send_state == SEND)
  {
    /*************************************************************************/
    /* In bracket and we have direction, so simply give direction.           */
    /*************************************************************************/
    other_verb.common.lua_rh.cdi         = 1;
    send_state = RECV;
  }
  else
  {
    /*************************************************************************/
    /* In bracket and we do not have direction, so do not send.              */
    /*************************************************************************/
   *Ret1=0;
   *Ret2=0;
   *Ret3=send_state;
   wsprintf(msgBuff,"%s",TEXT("In bracket with no direction.Cannot send."));
   retData=SysAllocStringByteLen(msgBuff,lstrlen(msgBuff));
   if (DebugIt!=0)                       // use it as debug flag
     {
       aInsertStrs[0] = "SEND";
       aInsertStrs[1] = crlf;
       aInsertStrs[2] = cicsBuff;
       aInsertStrs[3] = luBuff;
       aInsertStrs[4] = "In bracket with no direction.Cannot send.";
       reportAnEvent( EVENTLOG_ERROR_TYPE,
                      MSG_SLI_ERROR, /* the message to log */
                      5,              /* number of insert strings */
                      aInsertStrs,0,NULL);    /* the array of insert strings */
       if (DebugIt==2)
          MessageBox(NULL,msgBuff,TEXT("VB4SliSend Return Codes"),MB_OK);
      }
   return retData;
  }

  recv_verb.common.lua_data_length=0;

  memset(RecvBuff,0,DATASIZE);
  /*************************************************************************/
  /* Issue write verb                                                      */
  /*************************************************************************/
  SLI((LUA_VERB_RECORD *) &other_verb);
  
  if (other_verb.common.lua_flag2.async)
    {
     RetCode=wait_verb_complete (&other_verb,(int) TimeOut);
    }
  *MsgType=(long) other_verb.common.lua_message_type;
  *Ret1=(long) other_verb.common.lua_prim_rc;
  *Ret2=(long) other_verb.common.lua_sec_rc;
  *Ret3=send_state;

  if (RetCode==TIMEOUT_ERROR)
    {
     *Ret3=0;
     wsprintf(msgBuff,"%s",TEXT("Timeout on send"));
     retData=SysAllocStringByteLen(msgBuff,lstrlen(msgBuff));
     if (DebugIt!=0)                       // use it as debug flag
       {
        aInsertStrs[0] = "SEND";
        aInsertStrs[1] = crlf;
        aInsertStrs[2] = cicsBuff;
        aInsertStrs[3] = luBuff;
        reportAnEvent( EVENTLOG_ERROR_TYPE,
                       MSG_SLI_TIMEOUT, /* the message to log */
                       4,              /* number of insert strings */
                       aInsertStrs,0,NULL);    /* the array of insert strings */
        if (DebugIt==2)
           MessageBox(NULL,msgBuff,TEXT("SLI SEND Return Codes"),MB_OK);
       }
     return retData;
    }

  if (*Ret1==LUA_OK)
    {
     if (DebugIt!=0)
       {
        wsprintf(dataBuff,"%s",*Data);
        aInsertStrs[0] = "SEND";
        aInsertStrs[1] = crlf;
        aInsertStrs[2] = cicsBuff;
        aInsertStrs[3] = luBuff;
        aInsertStrs[4] = dataBuff;
        reportAnEvent( EVENTLOG_INFORMATION_TYPE,
                       MSG_SLI_SUCCESS, /* the message to log */
                       5,               /* number of insert strings */
                       aInsertStrs,     /* the array of insert strings */
                       (DWORD) *Len,
                       SendBuff);       
       }
     retData=SysAllocStringByteLen(NULL,0);
     if (recv_verb.common.lua_data_length>0)               // Check if we have
        *Len = recv_verb.common.lua_data_length;
     else
         *Len = 0;

     if ((*Len>0) && (ConvertIt!=0))
       {
        memset(SendBuff, 0, DATASIZE+1);
        memcpy(SendBuff,RecvBuff,*Len);
        convert_to_asc.opcode       = SV_CONVERT;
        convert_to_asc.direction    = SV_EBCDIC_TO_ASCII;
        convert_to_asc.char_set     = SV_G;
        convert_to_asc.source       = RecvBuff;
        convert_to_asc.target       = RecvBuff;
        convert_to_asc.len          = (unsigned short) (*Len);
        ACSSVC_C((LONG)((UCHAR FAR *)&convert_to_asc));
       }
     if (*Len>0)
        LenData=*Len;
     LastMsgType=(long) other_verb.common.lua_message_type;
     LastStatus=*Ret3;
     }
  else
      {
       GetLuaReturnCode( &other_verb.common,255,msgBuff);
       retData=SysAllocStringByteLen(msgBuff,lstrlen(msgBuff));
       if (DebugIt!=0)                       // use it as debug flag
         {
          aInsertStrs[0] = "SEND";
          aInsertStrs[1] = crlf;
          aInsertStrs[2] = cicsBuff;
          aInsertStrs[3] = luBuff;
          aInsertStrs[4] = msgBuff;
          reportAnEvent( EVENTLOG_ERROR_TYPE,
                         MSG_SLI_ERROR, /* the message to log */
                         5,              /* number of insert strings */
                         aInsertStrs,0,NULL);    /* the array of insert strings */
          if (DebugIt==2)
             MessageBox(NULL,msgBuff,TEXT("SLI SEND Return Codes"),MB_OK);
         }
       }
 return retData;
 }

BSTR WINAPI VB4SLIRECEIVE(long ConvertIt,
                          long TimeOut,
                          long *Len,
                          long *MsgType,
                          long *Ret1,
                          long *Ret2,
                          long *Ret3,
                          long DebugIt)
     
{
 BSTR retData;
 DWORD RetCode=0;
 if (Sid==0)
   {
    *Ret1= -1;
    *Ret2= -1;
    *Ret3=  0;
    *Len = 0;
    wsprintf(msgBuff,"%s",TEXT("Not connected!"));
    retData=SysAllocStringByteLen(msgBuff,lstrlen(msgBuff));
    if (DebugIt!=0)                       // use it as debug flag
      {
       aInsertStrs[0] = "RECEIVE";
       reportAnEvent( EVENTLOG_ERROR_TYPE,
                      MSG_SLI_NOT_CONNECTED, /* the message to log */
                      1,              /* number of insert strings */
                      aInsertStrs,0,NULL);    /* the array of insert strings */
       if (DebugIt==2)
          MessageBox(NULL,msgBuff,TEXT("VB4SliReceive Return Codes"),MB_OK);
      }
    return retData;
   }
 if (*Ret3>0)
    send_state=*Ret3;

 if (LenData>0)
   {
    if (DebugIt!=0)
      {
        aInsertStrs[0] = "RECEIVE";
        aInsertStrs[1] = crlf;
        aInsertStrs[2] = cicsBuff;
        aInsertStrs[3] = luBuff;
        aInsertStrs[4] = RecvBuff;
        reportAnEvent( EVENTLOG_INFORMATION_TYPE,
                       MSG_SLI_SUCCESS, /* the message to log */
                       5,               /* number of insert strings */
                       aInsertStrs,     /* the array of insert strings */
                       (DWORD) LenData,
                       SendBuff);
      }
    *Len=LenData;
    *MsgType=LastMsgType;
    retData=SysAllocStringByteLen(RecvBuff,LenData);
    memset(RecvBuff, 0, DATASIZE+1);
    *Ret1=(long) 0;
    *Ret2=(long) 0;
    *Ret3=LastStatus;
    LenData=0;
    LastStatus=0;
    LastMsgType=0;
   }
 else
     {
      if (rpq_neaded)
         rpq_neaded=issue_rpq((int) TimeOut,DebugIt,send_state);

      memset(&recv_verb, 0, sizeof(recv_verb));

      recv_verb.common.lua_sid              = Sid;
      recv_verb.common.lua_verb             = LUA_VERB_SLI;
      recv_verb.common.lua_verb_length      = sizeof(struct LUA_COMMON);
      recv_verb.common.lua_opcode           = LUA_OPCODE_SLI_RECEIVE;
      recv_verb.common.lua_max_length       = DATASIZE;
      recv_verb.common.lua_data_ptr         = RecvBuff;
      recv_verb.common.lua_post_handle      = RECVPOST;
      recv_verb.common.lua_flag1.lu_norm    = 1;
      recv_verb.common.lua_flag1.lu_exp     = 1;
      recv_verb.common.lua_flag1.sscp_norm  = 1;
      recv_verb.common.lua_flag1.sscp_exp   = 1;
      recv_verb.common.lua_data_length      = 0;
      *Len = 0;
      SLI((LUA_VERB_RECORD FAR *)&recv_verb);
      if (recv_verb.common.lua_flag2.async)
         RetCode=wait_verb_complete (&recv_verb,(int) TimeOut);

      *Ret1=(long) recv_verb.common.lua_prim_rc;
      *Ret2=(long) recv_verb.common.lua_sec_rc;
      *Ret3=send_state;
      *MsgType=(long) recv_verb.common.lua_message_type;
      if (RetCode==TIMEOUT_ERROR)
        {
         *Ret3=0;
         wsprintf(msgBuff,"%s",TEXT("Timeout on receive"));
         retData=SysAllocStringByteLen(msgBuff,lstrlen(msgBuff));
         if (DebugIt!=0)                       // use it as debug flag
           {
            aInsertStrs[0] = "RECEIVE";
            aInsertStrs[1] = crlf;
            aInsertStrs[2] = cicsBuff;
            aInsertStrs[3] = luBuff;
            reportAnEvent( EVENTLOG_ERROR_TYPE,
                           MSG_SLI_TIMEOUT, /* the message to log */
                           4,              /* number of insert strings */
                           aInsertStrs,0,NULL);    /* the array of insert strings */
            if (DebugIt==2)
               MessageBox(NULL,msgBuff,TEXT("SLI RECEIVE Return Codes"),MB_OK);
           }
         return retData;
        }

      if ( (RetCode!=0) || (recv_verb.common.lua_prim_rc != LUA_OK))
        {
         *Len = 0;
         GetLuaReturnCode( &recv_verb.common,255,msgBuff);
         retData=SysAllocStringByteLen(msgBuff,lstrlen(msgBuff));
         if (DebugIt!=0)                       // use it as debug flag
          {
           aInsertStrs[0] = "RECEIVE";
           aInsertStrs[1] = crlf;
           aInsertStrs[2] = cicsBuff;
           aInsertStrs[3] = luBuff;
           aInsertStrs[4] = msgBuff;
           reportAnEvent( EVENTLOG_ERROR_TYPE,
                          MSG_SLI_ERROR, /* the message to log */
                          5,              /* number of insert strings */
                          aInsertStrs,0,NULL);    /* the array of insert strings */
           if (DebugIt==2)
              MessageBox(NULL,msgBuff,TEXT("SLI RECEIVE Return Codes"),MB_OK);
          }
         return retData;
        }
      *Len = recv_verb.common.lua_data_length;

       if (recv_verb.common.lua_rh.ebi)
           send_state = BETB;
       else if (recv_verb.common.lua_rh.cdi)
            send_state = SEND;
       else
            send_state = RECV;

      if ( (recv_verb.common.lua_message_type == LUA_MESSAGE_TYPE_LU_DATA) &&
           (recv_verb.common.lua_data_length>0) )
        {
         /*************************************************************************/
         /* Respond to any RQD request.                                           */
         /*************************************************************************/
         if (parse_data(RecvBuff,(USHORT) recv_verb.common.lua_data_length))
            rpq_neaded=issue_rpq((int) TimeOut,DebugIt,send_state);
        }


      if (((recv_verb.common.lua_message_type != LUA_MESSAGE_TYPE_RSP)  &&
           (recv_verb.common.lua_rh.ri == 0)))            /* definite response */
        {
         issue_rsp(sense,(int) TimeOut,DebugIt,send_state);
        }
      if ( (*Len>0) )
        {
         memset(SendBuff, 0, DATASIZE+1);
         memcpy(SendBuff,RecvBuff,*Len);
         if (ConvertIt!=0)
           {
            convert_to_asc.opcode       = SV_CONVERT;
            convert_to_asc.direction    = SV_EBCDIC_TO_ASCII;
            convert_to_asc.char_set     = SV_G;
            convert_to_asc.source       = RecvBuff;
            convert_to_asc.target       = RecvBuff;
            convert_to_asc.len          = (unsigned short) recv_verb.common.lua_data_length;
            ACSSVC_C((LONG)((UCHAR FAR *)&convert_to_asc));
           }
        }
       *Ret3=send_state;
       retData=SysAllocStringByteLen(RecvBuff,*Len);
      if (DebugIt!=0)
        {
        aInsertStrs[0] = "RECEIVE";
        aInsertStrs[1] = crlf;
        aInsertStrs[2] = cicsBuff;
        aInsertStrs[3] = luBuff;
        aInsertStrs[4] = RecvBuff;
        if (*Len<2)
           aInsertStrs[4] = "None.";

        reportAnEvent( EVENTLOG_INFORMATION_TYPE,
                       MSG_SLI_SUCCESS, /* the message to log */
                       5,               /* number of insert strings */
                       aInsertStrs,     /* the array of insert strings */
                       (DWORD) *Len,
                       SendBuff);
         memset(RecvBuff, 0, DATASIZE+1);
        }

     }
 return retData;
}



/**PROC+**********************************************************************/
/* Name:      issue_rsp                                                      */
/*                                                                           */
/* Purpose:   issue a response for a request from the host                   */
/*                                                                           */
/* Returns:   void                                                           */
/*                                                                           */
/* Params:    IN sense - sense code for the response                         */
/*                                                                           */
/* Operation: Build a response and write it out.  Uses the recv verb control */
/*            block because it has the necessary information.                */
/*                                                                           */
/**PROC-**********************************************************************/
void issue_rsp(unsigned long sense,int TimeOut,long DebugIt,long PrevState)
{
  DWORD RetCode=0;
  LUA_VERB_RECORD rcv_verb;             /* SLI read verb                    */
  memset(msgBuff,0,sizeof(msgBuff));
  memcpy(&rcv_verb,&recv_verb, sizeof(recv_verb));

  rcv_verb.common.lua_sid              = Sid;
  rcv_verb.common.lua_data_ptr         = msgBuff;
  rcv_verb.common.lua_opcode           = LUA_OPCODE_SLI_SEND;
  rcv_verb.common.lua_max_length       = 0;
  rcv_verb.common.lua_post_handle      = (ULONG) RECVPOST;
  rcv_verb.common.lua_message_type     = LUA_MESSAGE_TYPE_RSP;
  rcv_verb.common.lua_verb_length      = sizeof(struct LUA_COMMON) +
                                sizeof(rcv_verb.specific.lua_sequence_number);

  rcv_verb.common.lua_rh.rri           = 1;        /* response              */
  rcv_verb.common.lua_flag1.lu_norm    = 0;
  rcv_verb.common.lua_flag1.lu_exp     = 0;
  rcv_verb.common.lua_flag1.sscp_norm  = 0;
  rcv_verb.common.lua_flag1.sscp_exp   = 0;

  /***************************************************************************/
  /* If we have been given a sense code this must be a negative response     */
  /***************************************************************************/
  if (sense)
  {
    rcv_verb.common.lua_data_length      = 4;
    memcpy(msgBuff, &sense, 4);
    rcv_verb.common.lua_rh.ri            = 1;       /* negative rsp         */
  }
  else
  {
    rcv_verb.common.lua_data_length      = 0;
    rcv_verb.common.lua_rh.ri            = 0;       /* positive rsp         */
  }
  /***************************************************************************/
  /* Send the response back on the flow from which the request came          */
  /***************************************************************************/
  if (recv_verb.common.lua_flag2.lu_norm)
  {
    rcv_verb.common.lua_flag1.lu_norm = 1;
  }
  else if (recv_verb.common.lua_flag2.lu_exp)
  {
    rcv_verb.common.lua_flag1.lu_exp = 1;
  }
  else if (recv_verb.common.lua_flag2.sscp_norm)
  {
    rcv_verb.common.lua_flag1.sscp_norm = 1;
  }
  else if (recv_verb.common.lua_flag2.sscp_exp)
  {
    rcv_verb.common.lua_flag1.sscp_exp = 1;
  }
  /***************************************************************************/
  /* Send out the verb                                                       */
  /***************************************************************************/
  SLI((LUA_VERB_RECORD FAR *)&rcv_verb);              /* write the response */
  if (rcv_verb.common.lua_flag2.async)
     RetCode=wait_verb_complete (&rcv_verb,TimeOut);
  if (DebugIt!=0)
    {
     aInsertStrs[0] = "RSP";
     aInsertStrs[1] = crlf;
     aInsertStrs[2] = cicsBuff;
     aInsertStrs[3] = luBuff;
     aInsertStrs[4] = msgBuff;
     if (rcv_verb.common.lua_prim_rc == LUA_OK)
        reportAnEvent( EVENTLOG_INFORMATION_TYPE,
                       MSG_SLI_SUCCESS, /* the message to log */
                       5,               /* number of insert strings */
                       aInsertStrs,     /* the array of insert strings */
                       (DWORD) 4,
                       msgBuff);
      else
          {
           GetLuaReturnCode( &rcv_verb.common,255,msgBuff);
           reportAnEvent( EVENTLOG_INFORMATION_TYPE,
                          MSG_SLI_ERROR, /* the message to log */
                          5,               /* number of insert strings */
                          aInsertStrs,     /* the array of insert strings */
                          0,
                          NULL);
           if (DebugIt==2)
              MessageBox(NULL,msgBuff,TEXT("ISSUE RSP Return Codes"),MB_OK);
         }
    }
   if (rcv_verb.common.lua_rh.ebi)
       send_state = BETB;
   else if (rcv_verb.common.lua_rh.cdi)
        send_state = SEND;
   else
        send_state = RECV;
  if ( PrevState != send_state)
    {
     if (DebugIt!=0)
      {
        if (send_state == BETB)
           aInsertStrs[2] = "New state: BETB";
        else if (send_state == SEND)
             aInsertStrs[2] = "New state: SEND";
        else
             aInsertStrs[2] = "New state: RECV";

        if (PrevState == BETB)
           aInsertStrs[4] = "Read state: BETB";
        else if (PrevState == SEND)
             aInsertStrs[4] = "Read state: SEND";
        else
             aInsertStrs[4] = "Read state: RECV";

        aInsertStrs[0] = "RSP-Change Bracket";
        aInsertStrs[1] = crlf;
        aInsertStrs[3] = luBuff;
        reportAnEvent( EVENTLOG_INFORMATION_TYPE,
                       MSG_SLI_SUCCESS, /* the message to log */
                       5,               /* number of insert strings */
                       aInsertStrs,     /* the array of insert strings */
                       (DWORD) 4,
                       msgBuff);
     }
     if (PrevState != RECV) send_state = PrevState;
   }

}  /* issue_rsp                                                              */




/**PROC+**********************************************************************/
/* Name:      wait_verb_complete                                             */
/*                                                                           */
/* Purpose:   waits for async verb completion                                */
/*                                                                           */
/* Returns:   void                                                           */
/*                                                                           */
/* Params:    IN - verb - pointer to verb control block                      */
/*                                                                           */
/* Operation: Wait for the lua_post_handle to become clear                   */
/*                                                                           */
/**PROC-**********************************************************************/
DWORD wait_verb_complete (LUA_VERB_RECORD * verb,int Seconds)
{
  DWORD RetCode=1;
  int TimeOut=0;
  while ((TimeOut++<Seconds) && (RetCode!=0))
       {
        RetCode = WaitForSingleObject((HANDLE)verb->common.lua_post_handle,
                                      (DWORD)1000l);
       }

  if (TimeOut>=Seconds)
     RetCode=TIMEOUT_ERROR;

  if (RetCode==0)
     ResetEvent ((HANDLE) verb->common.lua_post_handle);

  return RetCode;
}

/**PROC+**********************************************************************/
/* Name:      parse_data                                                     */
/*                                                                           */
/* Purpose:   parse data from the host                                       */
/*                                                                           */
/* Returns:   void                                                           */
/*                                                                           */
/* Params:    IN  data - pointer to data                                     */
/*                                                                           */
/* Operation: Looks through data for read partition query from host.  Could  */
/* be expanded to format data from host                                      */
/*                                                                           */
/**PROC-**********************************************************************/
BOOL parse_data (unsigned char *data,unsigned short length)

{
  USHORT  field_length;
  BOOL rpq_stat=FALSE;
  switch (*(data++))
  {
    case 0xF3:                       /* write structured field               */
      /***********************************************************************/
      /* Next byte is the WCC - ignore                                       */
      /***********************************************************************/
      data++;
      length -= 2;

      while (length > 0)
      {
        /*********************************************************************/
        /* We're just looking for a Read Partion query                       */
        /*********************************************************************/
        field_length = (((USHORT) *data) << 8) || ((USHORT) *(data + 1));
        if ((*(data+2) == 0x01) &&   /* Read partition                       */
            (*(data+3) == 0xFF) &&   /* Query                                */
            (*(data+4) == 0x02))     /* not a list                           */
        {
          /*******************************************************************/
          /* Build an RPQ and flag it to be sent                             */
          /*******************************************************************/
          rpq_stat = TRUE;
        }
        data   += field_length;
        length -= field_length;
      }


      break;

    default:
      break;

  }
 return rpq_stat;
}  /* parse_data                                                             */



/**PROC+**********************************************************************/
/* Name:      issue_rpq                                                      */
/*                                                                           */
/* Purpose:   issue a response to a Read partition query                     */
/*                                                                           */
/* Returns:   BOOL - TRUE => sent OK                                         */
/*                                                                           */
/* Params:    none                                                           */
/*                                                                           */
/* Operation: Builds and sends an RPQ reesponse                              */
/*                                                                           */
/**PROC-**********************************************************************/
BOOL issue_rpq (int TimeOut,long DebugIt,long PrevState)
{
  BOOL issue_rpq;
  issue_rpq = TRUE;

  /***************************************************************************/
  /* Set up the vcb                                                          */
  /***************************************************************************/
  memset(&rpq_verb, 0, sizeof(rpq_verb));
  rpq_verb.common.lua_verb             = LUA_VERB_SLI;
  rpq_verb.common.lua_verb_length      = sizeof(struct LUA_COMMON) +
                         sizeof(rpq_verb.specific.lua_sequence_number);
  rpq_verb.common.lua_opcode           = LUA_OPCODE_SLI_SEND;
  rpq_verb.common.lua_sid              = Sid;
  rpq_verb.common.lua_message_type     = LUA_MESSAGE_TYPE_LU_DATA;
  rpq_verb.common.lua_data_length      = RPQ_LENGTH;
  rpq_verb.common.lua_data_ptr         = (char far *) rpq_data;
  rpq_verb.common.lua_post_handle      = RPQPOST;
  rpq_verb.common.lua_rh.dr1i          = 1;

  /***************************************************************************/
  /* On the LU session we must add the <enter> key prefix.  All inbound      */
  /* requests flow RQE with the BBI and CDI flags set depending on the       */
  /* current session state.                                                  */
  /***************************************************************************/
  rpq_verb.common.lua_flag1.lu_norm  = 0;
  rpq_verb.common.lua_rh.ri          = 1;
  if (send_state == BETB)
  {
    /*************************************************************************/
    /* Between bracket, so open bracket and give direction.  Note that we    */
    /* can do this since we will always be contention winner.                */
    /*************************************************************************/
    rpq_verb.common.lua_rh.bbi         = 1;
    rpq_verb.common.lua_rh.cdi         = 1;
    send_state = RECV;
  }
  else if (send_state == SEND)
  {
    /*************************************************************************/
    /* In bracket and we have direction, so simply give direction.           */
    /*************************************************************************/
    rpq_verb.common.lua_rh.cdi         = 1;
    send_state = RECV;
  }
  else
  {
    /*************************************************************************/
    /* In bracket and we do not have direction, so do not send.              */
    /*************************************************************************/
    issue_rpq = FALSE;
  }
  if (PrevState != send_state)
    {
     if (DebugIt!=0)
      {
        if (send_state == BETB)
           aInsertStrs[2] = "New state: BETB";
        else if (send_state == SEND)
             aInsertStrs[2] = "New state: SEND";
        else
             aInsertStrs[2] = "New state: RECV";
        if (PrevState == BETB)
           aInsertStrs[4] = "Read state: BETB";
        else if (PrevState == SEND)
             aInsertStrs[4] = "Read state: SEND";
        else
             aInsertStrs[4] = "Read state: RECV";

        aInsertStrs[0] = "RPQ-Change Bracket";
        aInsertStrs[1] = crlf;
        aInsertStrs[3] = luBuff;
        reportAnEvent( EVENTLOG_INFORMATION_TYPE,
                       MSG_SLI_SUCCESS, /* the message to log */
                       5,               /* number of insert strings */
                       aInsertStrs,     /* the array of insert strings */
                       (DWORD) 4,
                       msgBuff);
     }
     if (PrevState != RECV) send_state = PrevState;
   }

  if (issue_rpq)
  {
    SLI((LUA_VERB_RECORD FAR *) &rpq_verb);

    if (rpq_verb.common.lua_flag2.async)
        wait_verb_complete (&recv_verb,TimeOut);

    if (DebugIt!=0)
      {
       aInsertStrs[0] = "RPQ";
       aInsertStrs[1] = crlf;
       aInsertStrs[2] = cicsBuff;
       aInsertStrs[3] = luBuff;
       aInsertStrs[4] = "none";
       if (rpq_verb.common.lua_prim_rc == LUA_OK)
          reportAnEvent( EVENTLOG_INFORMATION_TYPE,
                         MSG_SLI_SUCCESS, /* the message to log */
                         5,               /* number of insert strings */
                         aInsertStrs,     /* the array of insert strings */
                         0,
                         NULL);
       else
           {
            GetLuaReturnCode( &rpq_verb.common,255,msgBuff);
            aInsertStrs[4] = msgBuff;
            reportAnEvent( EVENTLOG_INFORMATION_TYPE,
                           MSG_SLI_ERROR, /* the message to log */
                           5,               /* number of insert strings */
                           aInsertStrs,     /* the array of insert strings */
                           0,
                           NULL);
             if (DebugIt==2)
                MessageBox(NULL,msgBuff,TEXT("ISSUE RPQ Return Codes"),MB_OK);
            }
      }
  }
  return(issue_rpq);
}  /* issue_rpq                                                              */

/*********************************************************************
* FUNCTION: reportAnEvent(DWORD dwIdEvent, WORD cStrings,            *
*                         LPTSTR *ppszStrings);                      *
*                                                                    *
* PURPOSE: add the event to the event log                            *
*                                                                    *
* INPUT: the event ID to report in the log, the number of insert     *
*        strings, and an array of null-terminated insert strings     *
*                                                                    *
* RETURNS: none                                                      *
*********************************************************************/

void reportAnEvent(WORD eType,DWORD dwIdEvent, WORD cStrings,
                   LPTSTR *pszStrings,DWORD cBytes,LPVOID data)
{
  HANDLE hAppLog;
  BOOL bSuccess;

  /* Get a handle to the Application event log */
  hAppLog = RegisterEventSource(NULL,   /* use local machine      */
                     "SNA VB4SLI");     /* source name                 */

  /* Now report the event, which will add this event to the event log */
  bSuccess = ReportEvent(hAppLog,       /* event-log handle            */
      eType,                    /* event type                  */
      0,                        /* category zero               */
      dwIdEvent,                /* event ID                    */
      NULL,                     /* no user SID                 */
      cStrings,                 /* number of substitution strings     */
      cBytes,                   /* no binary data              */
      pszStrings,               /* string array                */
      data);                    /* address of data             */
  DeregisterEventSource(hAppLog);
  return;
}


void addSourceToRegistry(LPSTR pszMsgDLL)
{
  HKEY hReg;
  DWORD dwData;
  BOOL bSuccess;

  /* When an application uses the RegisterEventSource or OpenEventLog
     function to get a handle of an event log, the event loggging service
     searches for the specified source name in the registry. You can add a
     new source name to the registry by opening a new registry subkey
     under the Application key and adding registry values to the new
     subkey. */
  /* Add the Event-ID message-file name to the subkey. */
  
  if (ERROR_SUCCESS != RegOpenKeyEx (HKEY_LOCAL_MACHINE,
                                     "SYSTEM\\CurrentControlSet\\Services\\EventLog\\Application\\SNA VB4SLI",
                                     0L,
                                     KEY_QUERY_VALUE | KEY_SET_VALUE,
                                     &hReg))
     {
      bSuccess = RegCreateKey(HKEY_LOCAL_MACHINE,
       "SYSTEM\\CurrentControlSet\\Services\\EventLog\\Application\\SNA VB4SLI",
       &hReg);
    }
  else 
      {
       RegCloseKey(hReg);
	   return;
      }

  bSuccess = RegSetValueEx(hReg,  /* subkey handle         */
      "EventMessageFile",       /* value name            */
      0,                        /* must be zero          */
      REG_EXPAND_SZ,            /* value type            */
      (LPBYTE) pszMsgDLL,       /* address of value data */
      strlen(pszMsgDLL) + 1);   /* length of value data  */

  /* Set the supported types flags and addit to the subkey. */
  dwData = EVENTLOG_ERROR_TYPE | EVENTLOG_WARNING_TYPE |
           EVENTLOG_INFORMATION_TYPE;
  bSuccess = RegSetValueEx(hReg,  /* subkey handle                */
      "TypesSupported",         /* value name                   */
      0,                        /* must be zero                 */
      REG_DWORD,                /* value type                   */
      (LPBYTE) &dwData,         /* address of value data        */
      sizeof(DWORD));           /* length of value data         */
  RegCloseKey(hReg);
  return;
}

unsigned char * WINAPI BSTR2String(BSTR bstring,int len)
{
 unsigned char *ptr,*tptr;
 int slen,step,i,bstep;
 slen=SysStringByteLen(bstring);
 if (len<1)
    tptr=ptr=calloc (slen+1,sizeof(char));
 else
     {
      if (slen>len)
         tptr=ptr=calloc (slen+1,sizeof(char));
      else
          tptr=ptr=calloc (len+1,sizeof(char));
     }
 wsprintf(tptr,"%s",bstring);
 step=lstrlen(tptr);
 if ((slen<1) || (step<2))
    return ptr;
 if (slen>step)
   {
	 bstep=(int) step/2;
     if (step!=bstep*2)
        step--;
     tptr=tptr+step;
     bstring=bstring+bstep;
     for (i=step;i<slen;i+=step)
		{
		 wsprintf(tptr,"%s",bstring);
         tptr=tptr+step;
         bstring=bstring+bstep;
		}
    }
 if (len>0)
    ptr[len]=0;
 return ptr;
}
 
